<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intranet - Sanchez Pharma</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/logo.png')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>?v=<?php echo e(time()); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <!-- ===================== SIDEBAR ===================== -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <button class="sidebar-toggle-mobile" onclick="toggleSidebar()"><i class="fas fa-times"></i></button>
            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo Sanchez Pharma">
            <h3>Droguería y Distribuidora<br>Sanchez Pharma</h3>
            <p>Intranet Administrativa</p>
        </div>

        <?php
            $u = auth()->user();
            $perms = $u->permissions ?? [];
            $can = function($p) use ($u, $perms) {
                // Solo el Ingeniero de Sistemas tiene acceso total incondicional
                // El Administrador y Supervisor dependen de los permisos marcados
                return $u->role === 'ing_sistemas' || in_array($p, $perms);
            };
        ?>

        <nav class="sidebar-nav">
            <div class="nav-section-title">Principal</div>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
                <i class="fas fa-home"></i> Dashboard
            </a>

            <div class="nav-section-title">Gestión Operativa</div>
            <?php if($can('productos')): ?>
            <a href="<?php echo e(route('admin.products.index')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.products.*') ? 'active' : ''); ?>">
                <i class="fas fa-pills"></i> Productos
            </a>
            <?php endif; ?>
            <?php if($can('laboratorios')): ?>
            <a href="<?php echo e(route('admin.laboratories.index')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.laboratories.*') ? 'active' : ''); ?>">
                <i class="fas fa-flask"></i> Laboratorios
            </a>
            <?php endif; ?>
            <?php if($can('zonas')): ?>
            <a href="<?php echo e(route('admin.zonas.index')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.zonas.*') ? 'active' : ''); ?>">
                <i class="fas fa-map-signs"></i> Zonas
            </a>
            <?php endif; ?>
            <?php if($can('unidad_medidas')): ?>
            <a href="<?php echo e(route('admin.unidad-medidas.index')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.unidad-medidas.*') ? 'active' : ''); ?>">
                <i class="fas fa-ruler-combined"></i> Unidades de Medida
            </a>
            <?php endif; ?>

            <div class="nav-section-title">Marketing & Contenido</div>
            <?php if($can('novedades')): ?>
            <a href="<?php echo e(route('admin.novedades.index')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.novedades.*') ? 'active' : ''); ?>">
                <i class="fas fa-newspaper"></i> Novedades
            </a>
            <?php endif; ?>
            <?php if($can('certificados')): ?>
            <a href="<?php echo e(route('admin.certificados.index')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.certificados.*') ? 'active' : ''); ?>">
                <i class="fas fa-certificate"></i> Certificaciones
            </a>
            <?php endif; ?>
            <?php if($can('banners')): ?>
            <a href="<?php echo e(route('admin.banners.index')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.banners.*') ? 'active' : ''); ?>">
                <i class="fas fa-images"></i> Banners
            </a>
            <?php endif; ?>

            <div class="nav-section-title">Ventas & Distribución</div>
            <?php if($can('representatives')): ?>
            <a href="<?php echo e(route('admin.representatives.index')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.representatives.*') ? 'active' : ''); ?>">
                <i class="fas fa-briefcase"></i> Ejecutivos
            </a>
            <?php endif; ?>
            <?php if($can('quotations')): ?>
            <a href="<?php echo e(route('admin.quotations.index')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.quotations.*') ? 'active' : ''); ?>">
                <i class="fas fa-file-invoice"></i> Cotizaciones
                <?php $pending = \App\Models\Quotation::where('estado', 'pendiente')->count(); ?>
                <?php if($pending > 0): ?>
                    <span class="badge badge-warning" style="margin-left: auto; font-size: 0.7rem; padding: 2px 8px;"><?php echo e($pending); ?></span>
                <?php endif; ?>
            </a>
            <?php endif; ?>

            <div class="nav-section-title">Administración</div>
            <?php if($can('users')): ?>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>">
                <i class="fas fa-users"></i> Usuarios
            </a>
            <?php endif; ?>
            
            <?php if($can('audit') || $can('access_logs')): ?>
            <div class="nav-section-title">Seguridad</div>
            <?php if($can('audit')): ?>
            <a href="<?php echo e(route('admin.security.audit')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.security.audit') ? 'active' : ''); ?>">
                <i class="fas fa-history"></i> Auditoría
            </a>
            <?php endif; ?>
            <?php if($can('access_logs')): ?>
            <a href="<?php echo e(route('admin.security.access')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.security.access') ? 'active' : ''); ?>">
                <i class="fas fa-sign-in-alt"></i> Registro Accesos
            </a>
            <?php endif; ?>
            <?php endif; ?>
            
            <div class="nav-section-title">Sistema</div>
            <?php if($can('reports')): ?>
            <a href="<?php echo e(route('admin.reports.index')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.reports.*') ? 'active' : ''); ?>">
                <i class="fas fa-chart-bar"></i> Reportes
            </a>
            <?php endif; ?>
            <?php if($can('backups')): ?>
            <a href="<?php echo e(route('admin.backups.index')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.backups.*') ? 'active' : ''); ?>">
                <i class="fas fa-database"></i> Backups
            </a>
            <?php endif; ?>
            <?php if($can('settings')): ?>
            <a href="<?php echo e(route('admin.settings.index')); ?>" class="nav-item <?php echo e(request()->routeIs('admin.settings.*') ? 'active' : ''); ?>">
                <i class="fas fa-cog"></i> Configuración
            </a>
            <?php endif; ?>
        </nav>

        <!-- Logout removido de aquí -->
    </div>
    </div>

    <!-- ===================== MAIN CONTENT ===================== -->
    <div class="main-content">
        <!-- Topbar -->
        <header class="topbar">
            <div style="display: flex; align-items: center; gap: 15px;">
                <button class="hamburger-btn" onclick="toggleSidebar()">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="topbar-info">
                    <span>Bienvenido,</span>
                    <span class="fw-bold" style="color: var(--text);"><?php echo e(auth()->user()->name); ?></span>
                    <span class="role-badge"><?php echo e(strtoupper(auth()->user()->role ?? 'Admin')); ?></span>
                </div>
            </div>

            <div class="user-profile">
                <!-- Notifications -->
                <?php
                    $pendingQuotations = \App\Models\Quotation::where('estado', 'pendiente')->latest()->take(5)->get();
                    $pendingCount = \App\Models\Quotation::where('estado', 'pendiente')->count();
                ?>
                <div class="notifications-wrapper">
                    <button class="notification-btn" id="notifBtn" type="button">
                        <i class="fas fa-bell"></i>
                        <?php if($pendingCount > 0): ?>
                            <span class="notification-badge"><?php echo e($pendingCount > 9 ? '9+' : $pendingCount); ?></span>
                        <?php endif; ?>
                    </button>

                    <div class="notifications-dropdown" id="notifDropdown">
                        <div class="notif-header">
                            <h4><i class="fas fa-bell" style="color: var(--primary); margin-right: 6px;"></i> Notificaciones</h4>
                            <?php if($pendingCount > 0): ?>
                                <span class="badge badge-warning"><?php echo e($pendingCount); ?> nueva<?php echo e($pendingCount > 1 ? 's' : ''); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="notif-list">
                            <?php $__empty_1 = true; $__currentLoopData = $pendingQuotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <a href="<?php echo e(route('admin.quotations.index')); ?>" class="notif-item">
                                    <div class="notif-icon"><i class="fas fa-file-invoice"></i></div>
                                    <div class="notif-content">
                                        <span class="notif-title">Cotización #<?php echo e(str_pad($notif->id, 5, '0', STR_PAD_LEFT)); ?></span>
                                        <span class="notif-text"><?php echo e($notif->nombre); ?> <?php echo e($notif->apellidos); ?></span>
                                        <span class="notif-time"><?php echo e($notif->created_at->diffForHumans()); ?></span>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="notif-empty">
                                    <i class="fas fa-check-circle" style="color: var(--primary); font-size: 2rem; display: block; margin-bottom: 8px;"></i>
                                    Sin cotizaciones pendientes
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="notif-footer">
                            <a href="<?php echo e(route('admin.quotations.index')); ?>">Ver todas las cotizaciones →</a>
                        </div>
                    </div>
                </div>

                <div style="width: 1px; height: 28px; background: var(--border);"></div>

                <div class="profile-dropdown-wrapper">
                    <button class="profile-toggle-btn" id="profileBtn">
                        <div class="avatar-circle">
                            <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

                        </div>
                        <div class="profile-info-text">
                            <span class="profile-name"><?php echo e(auth()->user()->name); ?></span>
                            <span class="profile-role"><?php echo e(strtoupper(auth()->user()->role ?? 'Admin')); ?></span>
                        </div>
                        <i class="fas fa-chevron-down" style="font-size: 0.7rem; opacity: 0.5;"></i>
                    </button>

                    <div class="profile-dropdown" id="profileDropdown">
                        <div class="dropdown-section">
                            <span class="dropdown-label">MI CUENTA</span>
                        </div>
                        <a href="<?php echo e(route('admin.settings.index')); ?>" class="dropdown-item">
                            <i class="fas fa-cog"></i> Configuración
                        </a>
                        <div style="border-top: 1px solid #f1f5f9; margin: 5px 0;"></div>
                        <form action="<?php echo e(route('logout')); ?>" method="POST" id="logout-form-dropdown">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="dropdown-item logout-link">
                                <i class="fas fa-sign-out-alt"></i> Salir
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </header>

        <!-- Content -->
        <div class="content-area">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo e($errors->first()); ?>

                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <!-- ===================== SCRIPTS ===================== -->
    <script>
        // Modal Helpers
        function openModal(id) {
            const el = document.getElementById(id);
            if (el) { el.style.display = 'flex'; document.body.style.overflow = 'hidden'; }
        }
        function closeModal(id) {
            const el = document.getElementById(id);
            if (el) { el.style.display = 'none'; document.body.style.overflow = ''; }
        }

        // Delete Confirm
        function confirmDelete(id, code, name, action) {
            Swal.fire({
                title: '¿Eliminar registro?',
                html: `<div style="text-align:left; font-size: 0.95rem; color: #475569;">
                    <p style="margin-bottom: 8px;"><strong>Código:</strong> ${code}</p>
                    <p style="margin-bottom: 0;"><strong>Descripción:</strong> ${name}</p>
                </div>`,
                icon: 'warning',
                iconColor: '#f59e0b',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#64748b',
                confirmButtonText: '<i class="fas fa-trash"></i> Sí, eliminar',
                cancelButtonText: 'Cancelar',
                customClass: { popup: 'swal-custom', confirmButton: 'swal-btn-confirm', cancelButton: 'swal-btn-cancel' }
            }).then((result) => {
                if (result.isConfirmed) {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = action;
                    form.innerHTML = `<?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>`;
                    document.body.appendChild(form);
                    form.submit();
                }
            });
        }

        // Sidebar Toggle
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.querySelector('.main-content');
            
            if (window.innerWidth <= 968) {
                sidebar.classList.toggle('show-mobile');
            } else {
                sidebar.classList.toggle('collapsed');
                mainContent.classList.toggle('expanded');
            }
        }

        // Notification Dropdown
        const notifBtn = document.getElementById('notifBtn');
        const notifDropdown = document.getElementById('notifDropdown');
        const profileBtn = document.getElementById('profileBtn');
        const profileDropdown = document.getElementById('profileDropdown');

        if (notifBtn) {
            notifBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                notifDropdown.classList.toggle('show');
                profileDropdown?.classList.remove('show');
            });
        }

        if (profileBtn) {
            profileBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                profileDropdown.classList.toggle('show');
                notifDropdown?.classList.remove('show');
            });
        }

        document.addEventListener('click', (e) => {
            if (!e.target.closest('.notifications-wrapper')) {
                notifDropdown?.classList.remove('show');
            }
            if (!e.target.closest('.profile-dropdown-wrapper')) {
                profileDropdown?.classList.remove('show');
            }
        });

        // Close modal on backdrop click
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) closeModal(e.target.id);
        });

        // Close modal on ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal').forEach(m => {
                    if (m.style.display === 'flex') closeModal(m.id);
                });
            }
        });
    </script>

    <!-- Global Delete Modal (fallback) -->
    <div id="deleteModal" class="modal">
        <div class="modal-content" style="max-width: 420px;">
            <div class="modal-header">
                <h3><i class="fas fa-exclamation-triangle" style="background: #fef3c7; color: #f59e0b;"></i> Confirmar Eliminación</h3>
                <button class="close-modal" onclick="closeModal('deleteModal')">&times;</button>
            </div>
            <div class="modal-body" style="text-align: center; padding: 32px;">
                <div style="width: 72px; height: 72px; border-radius: 50%; background: #fef3c7; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 2rem; color: #f59e0b;">
                    <i class="fas fa-exclamation"></i>
                </div>
                <p style="color: #475569; margin-bottom: 16px;">¿Estás seguro de eliminar este registro?</p>
                <div style="background: #f8fafc; border-radius: 10px; padding: 14px; text-align: left; font-size: 0.9rem; margin-bottom: 24px;">
                    <p><strong>Código:</strong> <span id="delete-item-code"></span></p>
                    <p style="margin-top: 6px;"><strong>Nombre:</strong> <span id="delete-item-name"></span></p>
                </div>
                <p style="color: #ef4444; font-size: 0.85rem;"><i class="fas fa-exclamation-circle"></i> Esta acción no se puede deshacer.</p>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="closeModal('deleteModal')">Cancelar</button>
                <form id="delete-form" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Eliminar</button>
                </form>
            </div>
        </div>
    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\ddsp+app\resources\views/layouts/admin.blade.php ENDPATH**/ ?>