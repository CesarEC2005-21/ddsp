<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h2 class="page-title">Gestión de Novedades</h2>
        <button onclick="openModal('newNovedadModal')" class="btn btn-primary">
            <i class="fas fa-plus"></i> Nueva Novedad
        </button>
    </div>

    <div class="card" style="margin-bottom: 20px; padding: 20px; background: white; border-radius: 12px; box-shadow: var(--shadow-sm);">
        <form action="<?php echo e(route('admin.novedades.index')); ?>" method="GET">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; align-items: end;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-size: 0.85rem;">Código</label>
                    <input type="text" name="codigo" class="form-control" value="<?php echo e(request('codigo')); ?>" placeholder="Ej. NOT-001">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-size: 0.85rem;">Descripción</label>
                    <input type="text" name="descripcion" class="form-control" value="<?php echo e(request('descripcion')); ?>" placeholder="Buscar...">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-size: 0.85rem;">Fecha Inicial</label>
                    <input type="date" name="fecha_inicial" class="form-control" value="<?php echo e(request('fecha_inicial')); ?>" max="9999-12-31">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-size: 0.85rem;">Fecha Final</label>
                    <input type="date" name="fecha_final" class="form-control" value="<?php echo e(request('fecha_final')); ?>" max="9999-12-31">
                </div>
                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="btn btn-primary" style="flex: 1;"><i class="fas fa-search"></i> Filtrar</button>
                    <?php if(request()->anyFilled(['codigo', 'descripcion', 'fecha_inicial', 'fecha_final'])): ?>
                        <a href="<?php echo e(route('admin.novedades.index')); ?>" class="btn" style="background: #f1f5f9; color: #475569;" title="Limpiar"><i class="fas fa-times"></i></a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>

    <div class="card">
        <div class="table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Imagen</th>
                        <th>Código</th>
                        <th>Tipo / Laboratorio</th>
                        <th>Descripción</th>
                        <th>Fechas</th>
                        <th>Estado</th>
                        <th>Autor</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $novedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $novedad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php if($novedad->imagen): ?>
                                <img src="<?php echo e(asset('storage/' . $novedad->imagen)); ?>" style="width: 50px; height: 50px; object-fit: cover; border-radius: 8px; cursor: pointer;" onclick="viewImageModal('<?php echo e(asset('storage/' . $novedad->imagen)); ?>', '<?php echo e($novedad->descripcion); ?>')">
                            <?php else: ?>
                                <div style="width: 50px; height: 50px; background: #f8fafc; display: flex; align-items: center; justify-content: center; border-radius: 8px; color: #cbd5e1;"><i class="fas fa-image"></i></div>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge badge-success"><?php echo e($novedad->codigo); ?></span></td>
                        <td>
                            <span class="badge <?php echo e($novedad->tipo == 'PROMOCION' ? 'badge-primary' : 'badge-warning'); ?>" style="display: block; margin-bottom: 5px;"><?php echo e($novedad->tipo); ?></span>
                            <span style="font-size: 0.85rem; color: #64748b;"><i class="fas fa-flask"></i> <?php echo e($novedad->laboratory->descripcion ?? 'General'); ?></span>
                        </td>
                        <td style="font-weight: 500;"><?php echo e(\Str::limit($novedad->descripcion, 50)); ?></td>
                        <td style="font-size: 0.85rem;">
                            <i class="far fa-calendar-alt text-muted"></i> <?php echo e(\Carbon\Carbon::parse($novedad->fecha_inicial)->format('d/m/Y')); ?> <br>
                            <i class="far fa-calendar-check text-muted"></i> <?php echo e(\Carbon\Carbon::parse($novedad->fecha_final)->format('d/m/Y')); ?>

                        </td>
                        <td>
                            <?php if($novedad->estado): ?>
                                <span class="badge badge-success">Activo</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Inactivo</span>
                            <?php endif; ?>
                        </td>
                        <td style="font-size: 0.85rem; color: #64748b;"><i class="fas fa-user-edit"></i> <?php echo e($novedad->user->name ?? 'Sistema'); ?></td>
                        <td>
                            <button onclick='openEditModal(<?php echo json_encode($novedad, 15, 512) ?>)' class="btn" style="background: #f3f4f6; color: #333; padding: 6px 10px;" title="Editar"><i class="fas fa-edit"></i></button>
                            <button onclick="confirmDelete(<?php echo e($novedad->id); ?>, '<?php echo e($novedad->codigo); ?>', 'Novedad', '<?php echo e(route('admin.novedades.destroy', $novedad->id)); ?>')" class="btn" style="background: #fee2e2; color: #ef4444; padding: 6px 10px;" title="Eliminar"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" style="padding: 30px; text-align: center; color: #888;">No hay novedades registradas.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div style="padding: 20px; border-top: 1px solid #eee; display: flex; justify-content: center;">
            <?php echo e($novedades->appends(request()->query())->links('partials.pagination')); ?>

        </div>
    </div>

    <!-- Modal Nueva Novedad -->
    <div id="newNovedadModal" class="modal">
        <div class="modal-content" style="max-width: 850px; padding: 0; max-height: 90vh; display: flex; flex-direction: column; overflow: hidden; border: none; border-radius: 20px;">
            <div class="modal-header" style="background: #1e293b; color: white; padding: 20px 30px; display: flex; justify-content: space-between; align-items: center; flex-shrink: 0;">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <div style="background: rgba(16, 185, 129, 0.2); width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-newspaper" style="color: #10b981; font-size: 1.2rem;"></i>
                    </div>
                    <h3 style="margin: 0; font-size: 1.25rem; font-weight: 700; color: #ffffff;">Registrar Nueva Novedad</h3>
                </div>
                <span class="close-modal" onclick="closeModal('newNovedadModal')" style="background: rgba(255,255,255,0.1); width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: white; cursor: pointer;">&times;</span>
            </div>
            <div class="modal-body" style="padding: 40px; overflow-y: auto; flex: 1;">
                <form action="<?php echo e(route('admin.novedades.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                    <!-- Sección Información -->
                    <div style="margin-bottom: 35px;">
                        <h4 style="display: flex; align-items: center; gap: 12px; color: #1e293b; margin-bottom: 8px; font-weight: 700;">
                            <div style="background: #10b981; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.8rem;">
                                <i class="fas fa-info"></i>
                            </div>
                            Información de la Novedad
                        </h4>
                        <p style="color: #64748b; font-size: 0.95rem; margin-bottom: 25px;">Complete los datos básicos de la noticia para el portal.</p>
                        
                        <div class="form-group">
                            <label class="form-label" style="color: #475569; font-weight: 600;">Título Atractivo del Producto</label>
                            <div style="position: relative;">
                                <i class="fas fa-tag" style="position: absolute; left: 18px; top: 16px; color: #94a3b8;"></i>
                                <input type="text" name="descripcion" class="form-control" style="padding: 14px 14px 14px 50px; border-radius: 12px; border: 1.5px solid #e2e8f0; background: #fcfcfc;" placeholder="Ej. ¡Súper Promoción Pulmol!" required>
                            </div>
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                            <div class="form-group">
                                <label class="form-label" style="color: #475569; font-weight: 600;">Laboratorio</label>
                                <select name="laboratory_id" class="form-control" style="padding: 12px; border-radius: 12px; border: 1.5px solid #e2e8f0;">
                                    <option value="">Seleccionar...</option>
                                    <?php $__currentLoopData = $laboratories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($lab->id); ?>"><?php echo e($lab->descripcion); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" style="color: #475569; font-weight: 600;">Tipo Novedad</label>
                                <select name="tipo" class="form-control" style="padding: 12px; border-radius: 12px; border: 1.5px solid #e2e8f0;">
                                    <option value="PROMOCION">PROMOCIÓN</option>
                                    <option value="EVENTO">EVENTO</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" style="color: #475569; font-weight: 600;">Imagen Promo</label>
                                <input type="file" name="imagen" class="form-control" style="padding: 8px; border-radius: 12px;" accept="image/*" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label" style="color: #475569; font-weight: 600;">Descripción Detallada</label>
                            <textarea name="detalle" class="form-control" style="border-radius: 15px; padding: 15px; border: 1.5px solid #e2e8f0;" rows="3" placeholder="Resumen detallado para los clientes..."></textarea>
                        </div>
                    </div>

                    <!-- Sección Especificaciones -->
                    <div style="margin-bottom: 35px;">
                        <h4 style="display: flex; align-items: center; gap: 12px; color: #1e293b; margin-bottom: 8px; font-weight: 700;">
                            <div style="background: #10b981; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.8rem;">
                                <i class="fas fa-calendar-check"></i>
                            </div>
                            Vigencia y Vinculación
                        </h4>
                        <p style="color: #64748b; font-size: 0.95rem; margin-bottom: 25px;">Información de tiempo y relación con productos.</p>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px;">
                            <div class="form-group">
                                <label class="form-label" style="color: #475569; font-weight: 600;">Producto del Catálogo (Opcional)</label>
                                <div style="display: flex; gap: 10px;">
                                    <div style="flex: 1; position: relative;">
                                        <i class="fas fa-barcode" style="position: absolute; left: 18px; top: 16px; color: #94a3b8;"></i>
                                        <input type="hidden" name="product_id" id="new-product-id">
                                        <input type="text" id="new-product-display" class="form-control" style="padding-left: 50px; border-radius: 12px; background: #f8fafc; cursor: pointer;" readonly placeholder="Buscar producto..." onclick="openProductPicker('new')">
                                    </div>
                                    <button type="button" class="btn btn-primary" style="border-radius: 12px; width: 50px;" onclick="openProductPicker('new')">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="form-group">
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                    <div>
                                        <label class="form-label" style="color: #475569; font-weight: 600;">Fecha Inicio</label>
                                        <input type="date" name="fecha_inicial" class="form-control" style="border-radius: 12px;" max="9999-12-31" required>
                                    </div>
                                    <div>
                                        <label class="form-label" style="color: #475569; font-weight: 600;">Fecha Fin</label>
                                        <input type="date" name="fecha_final" class="form-control" style="border-radius: 12px;" max="9999-12-31" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer" style="padding: 25px 40px; background: white; border-top: 1px solid #f1f5f9;">
                    <button type="button" class="btn" style="background: #f1f5f9; color: #64748b; font-weight: 600; padding: 12px 25px;" onclick="closeModal('newNovedadModal')">Cancelar</button>
                    <button type="submit" class="btn btn-primary" style="padding: 12px 40px; font-weight: 700; box-shadow: 0 4px 12px rgba(46, 125, 50, 0.2);">
                        <i class="fas fa-check-circle"></i> Finalizar y Guardar
                    </button>
                </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Editar Novedad -->
    <div id="editNovedadModal" class="modal">
        <div class="modal-content" style="max-width: 850px; padding: 0; max-height: 90vh; display: flex; flex-direction: column; overflow: hidden; border: none; border-radius: 20px;">
            <div class="modal-header" style="background: #1e293b; color: white; padding: 20px 30px; display: flex; justify-content: space-between; align-items: center; flex-shrink: 0;">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <div style="background: rgba(245, 158, 11, 0.2); width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-edit" style="color: #f59e0b; font-size: 1.2rem;"></i>
                    </div>
                    <h3 style="margin: 0; font-size: 1.25rem; font-weight: 700; color: #ffffff;">Editar Novedad</h3>
                </div>
                <span class="close-modal" onclick="closeModal('editNovedadModal')" style="background: rgba(255,255,255,0.1); width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: white; cursor: pointer;">&times;</span>
            </div>
            <div class="modal-body" style="padding: 40px; overflow-y: auto; flex: 1;">
                <form id="editNovedadForm" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <!-- Sección Información -->
                    <div style="margin-bottom: 35px;">
                        <h4 style="display: flex; align-items: center; gap: 12px; color: #1e293b; margin-bottom: 8px; font-weight: 700;">
                            <div style="background: #f59e0b; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.8rem;">
                                <i class="fas fa-info"></i>
                            </div>
                            Información de la Novedad
                        </h4>
                        <p style="color: #64748b; font-size: 0.95rem; margin-bottom: 25px;">Actualice los datos comerciales de la novedad.</p>
                        
                        <div class="form-group">
                            <label class="form-label" style="color: #475569; font-weight: 600;">Título Atractivo del Producto</label>
                            <div style="position: relative;">
                                <i class="fas fa-tag" style="position: absolute; left: 18px; top: 16px; color: #94a3b8;"></i>
                                <input type="text" name="descripcion" id="edit-descripcion" class="form-control" style="padding: 14px 14px 14px 50px; border-radius: 12px; border: 1.5px solid #e2e8f0;" required>
                            </div>
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                            <div class="form-group">
                                <label class="form-label" style="color: #475569; font-weight: 600;">Laboratorio</label>
                                <select name="laboratory_id" id="edit-laboratory_id" class="form-control" style="padding: 12px; border-radius: 12px;">
                                    <option value="">Seleccionar...</option>
                                    <?php $__currentLoopData = $laboratories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($lab->id); ?>"><?php echo e($lab->descripcion); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" style="color: #475569; font-weight: 600;">Tipo Novedad</label>
                                <select name="tipo" id="edit-tipo" class="form-control" style="padding: 12px; border-radius: 12px;">
                                    <option value="PROMOCION">PROMOCIÓN</option>
                                    <option value="EVENTO">EVENTO</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" style="color: #475569; font-weight: 600;">Actualizar Imagen</label>
                                <input type="file" name="imagen" class="form-control" style="padding: 8px; border-radius: 12px;" accept="image/*">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label" style="color: #475569; font-weight: 600;">Descripción Detallada</label>
                            <textarea name="detalle" id="edit-detalle" class="form-control" style="border-radius: 15px; padding: 15px;" rows="3"></textarea>
                        </div>
                    </div>

                    <!-- Sección Especificaciones -->
                    <div style="margin-bottom: 35px;">
                        <h4 style="display: flex; align-items: center; gap: 12px; color: #1e293b; margin-bottom: 8px; font-weight: 700;">
                            <div style="background: #f59e0b; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.8rem;">
                                <i class="fas fa-calendar-check"></i>
                            </div>
                            Vigencia y Vinculación
                        </h4>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px;">
                            <div class="form-group">
                                <label class="form-label" style="color: #475569; font-weight: 600;">Producto Vinculado</label>
                                <div style="display: flex; gap: 10px;">
                                    <div style="flex: 1; position: relative;">
                                        <i class="fas fa-barcode" style="position: absolute; left: 18px; top: 16px; color: #94a3b8;"></i>
                                        <input type="hidden" name="product_id" id="edit-product_id">
                                        <input type="text" id="edit-product-display" class="form-control" style="padding-left: 50px; border-radius: 12px; background: #f8fafc;" readonly onclick="openProductPicker('edit')">
                                    </div>
                                    <button type="button" class="btn btn-primary" style="border-radius: 12px; width: 50px;" onclick="openProductPicker('edit')">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="form-group">
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                    <div>
                                        <label class="form-label" style="color: #475569; font-weight: 600;">Fecha Inicio</label>
                                        <input type="date" name="fecha_inicial" id="edit-fecha-inicial" class="form-control" style="border-radius: 12px;" max="9999-12-31" required>
                                    </div>
                                    <div>
                                        <label class="form-label" style="color: #475569; font-weight: 600;">Fecha Fin</label>
                                        <input type="date" name="fecha_final" id="edit-fecha-final" class="form-control" style="border-radius: 12px;" max="9999-12-31" required>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group" style="margin-top: 20px;">
                            <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; background: #fdfaf3; padding: 15px; border-radius: 12px; border: 1.5px solid #fef3c7;">
                                <input type="checkbox" name="estado" id="edit-estado" value="1" style="width: 20px; height: 20px; accent-color: #f59e0b;">
                                <span style="font-weight: 700; color: #92400e;">Publicación Activa</span>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer" style="padding: 25px 40px; background: white; border-top: 1px solid #f1f5f9;">
                    <button type="button" class="btn" style="background: #f1f5f9; color: #64748b; font-weight: 600; padding: 12px 25px;" onclick="closeModal('editNovedadModal')">Cancelar</button>
                    <button type="submit" class="btn btn-primary" style="padding: 12px 40px; font-weight: 700; box-shadow: 0 4px 12px rgba(46, 125, 50, 0.2);">
                        <i class="fas fa-save"></i> Guardar Cambios
                    </button>
                </div>
                </form>
            </div>
        </div>
    </div> </div>
    </div>

    <!-- Modal Buscador de Productos -->
    <div id="productSearchModal" class="modal">
        <div class="modal-content" style="max-width: 800px;">
            <div class="modal-header">
                <h3><i class="fas fa-search"></i> Seleccionar Producto</h3>
                <span class="close-modal" onclick="closeModal('productSearchModal')">&times;</span>
            </div>
            <div class="modal-body">
                <div class="form-group" style="position: relative; margin-bottom: 20px;">
                    <i class="fas fa-search" style="position: absolute; left: 15px; top: 14px; color: #94a3b8;"></i>
                    <input type="text" id="productSearchInput" class="form-control" style="padding-left: 45px;" placeholder="Buscar por código SKU o nombre del producto..." onkeyup="filterProductsInPicker()">
                </div>
                
                <div style="max-height: 400px; overflow-y: auto; border: 1px solid #e2e8f0; border-radius: 12px;">
                    <table class="admin-table" style="margin-bottom: 0;">
                        <thead style="position: sticky; top: 0; background: #f8fafc; z-index: 5;">
                            <tr>
                                <th>Código</th>
                                <th>Nombre del Producto</th>
                                <th>Laboratorio</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody id="productPickerBody">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="product-picker-row" data-id="<?php echo e($prod->id); ?>" data-code="<?php echo e($prod->codigo); ?>" data-name="<?php echo e($prod->nombre); ?>">
                                <td><span class="badge badge-success"><?php echo e($prod->codigo); ?></span></td>
                                <td style="font-weight: 600;"><?php echo e($prod->nombre); ?></td>
                                <td><?php echo e($prod->laboratory->descripcion ?? 'N/A'); ?></td>
                                <td>
                                    <button type="button" class="btn btn-primary btn-sm" onclick="selectProductFromPicker(<?php echo e($prod->id); ?>, '<?php echo e($prod->codigo); ?>', '<?php echo e($prod->nombre); ?>')">
                                        Seleccionar
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    let currentPickerTarget = 'new'; // 'new' or 'edit'

    function openProductPicker(target) {
        currentPickerTarget = target;
        document.getElementById('productSearchInput').value = '';
        filterProductsInPicker(); // Reset filter
        openModal('productSearchModal');
    }

    function filterProductsInPicker() {
        const input = document.getElementById('productSearchInput').value.toLowerCase();
        const rows = document.querySelectorAll('.product-picker-row');
        
        rows.forEach(row => {
            const code = row.getAttribute('data-code').toLowerCase();
            const name = row.getAttribute('data-name').toLowerCase();
            if (code.includes(input) || name.includes(input)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    function selectProductFromPicker(id, code, name) {
        if (currentPickerTarget === 'new') {
            document.getElementById('new-product-id').value = id;
            document.getElementById('new-product-display').value = `${code} - ${name}`;
        } else {
            document.getElementById('edit-product_id').value = id;
            document.getElementById('edit-product-display').value = `${code} - ${name}`;
        }
        closeModal('productSearchModal');
    }

    function clearProductPicker(target) {
        if (target === 'new') {
            document.getElementById('new-product-id').value = '';
            document.getElementById('new-product-display').value = '';
        } else {
            document.getElementById('edit-product_id').value = '';
            document.getElementById('edit-product-display').value = '';
        }
    }

    function openEditModal(noticia) {
        const form = document.getElementById('editNovedadForm');
        form.action = `/admin/novedades/${novedad.id}`;
        
        document.getElementById('edit-tipo').value = novedad.tipo;
        document.getElementById('edit-laboratory_id').value = novedad.laboratory_id || '';
        document.getElementById('edit-descripcion').value = novedad.descripcion;
        document.getElementById('edit-detalle').value = novedad.detalle || '';
        document.getElementById('edit-fecha-inicial').value = novedad.fecha_inicial;
        document.getElementById('edit-fecha-final').value = novedad.fecha_final;
        document.getElementById('edit-estado').checked = !!novedad.estado;

        // Set linked product if exists
        if (novedad.product_id && novedad.product) {
            document.getElementById('edit-product_id').value = novedad.product_id;
            document.getElementById('edit-product-display').value = `${novedad.product.codigo} - ${novedad.product.nombre}`;
        } else {
            document.getElementById('edit-product_id').value = '';
            document.getElementById('edit-product-display').value = '';
        }
        
        openModal('editNovedadModal');
    }

    function viewImageModal(src, desc) {
        document.getElementById('view-image-src').src = src;
        document.getElementById('view-image-desc').innerText = desc;
        openModal('viewImageModal');
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\ddsp+app\resources\views/admin/novedades/index.blade.php ENDPATH**/ ?>